import pygame
from pygame.sprite import Sprite
from pygame.surface import Surface
from pygame.event import Event
from pygame.key import ScancodeWrapper
from config import CFG

from random import randint

class Spaceship(Sprite):
    def __init__(self, x = 100, y = 100, h = 64, w = 64):
        Sprite.__init__(self)
        
        self.speed = 5
        
        self.image = Surface((h, w))
        self.image.fill((255, 255, 255))
        self.rect = self.image.get_rect()
        self.rect.x = x
        self.rect.y = y
    
    def try_move_left(self):
        if (self.rect.x - self.speed < 0):
            return
        self.rect.move_ip(-self.speed, 0)
    
    def try_move_right(self):
        if (self.rect.right + self.speed > CFG.WIDTH):
            return
        self.rect.move_ip(self.speed, 0)
    
    def try_move_up(self):
        if (self.rect.top - self.speed < 0):
            return
        self.rect.move_ip(0, -self.speed)
            
    def try_move_down(self):
        if (self.rect.bottom + self.speed > CFG.HEIGHT):
            return
        self.rect.move_ip(0, self.speed)
    
    def update(self):
        key = pygame.key.get_pressed()
        if key[pygame.K_DOWN]:
            self.try_move_down()
        if key[pygame.K_UP]:
            self.try_move_up()
        if key[pygame.K_LEFT]:
            self.try_move_left()
        if key[pygame.K_RIGHT]:
            self.try_move_right()

class Enemy(Spaceship):
    
    def __init__(self, x=10, y=10, h=64, w=64):
        super().__init__(x, y, h, w)

    def update(self):
        (x, y) = randint(0, 1), randint(0, 1)
        if x == 0:
            self.try_move_down()
        if x == 1:
            self.try_move_up()
        if y == 0:
            self.try_move_left()
        if y == 1:
            self.try_move_right()