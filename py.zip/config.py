
class CFG:
    WIDTH = 480
    HEIGHT = 640
    TITLE = "SHOOTEMUP!"
    WINDOW_SIZE = (WIDTH, HEIGHT)

        