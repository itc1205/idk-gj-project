from config import CFG
from init import init_window
from drawables import Spaceship, Enemy

import pygame


def main():
    clock = pygame.time.Clock()    
    screen = init_window()
    spc = Spaceship(100, 100)
    en = Enemy(10, 10, 20, 20)
    running = True
    
    while running:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running = False
        spc.update()
        en.update()
        screen.fill((0, 0, 0))
        screen.blit(spc.image, spc.rect)
        screen.blit(en.image, en.rect)
        pygame.display.update()
        clock.tick(75)
    
if __name__ == "__main__":
    main()